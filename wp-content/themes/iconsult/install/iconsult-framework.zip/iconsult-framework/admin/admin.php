<?php
require ICONSULTSUPPORT_PLUGIN_DIR . '/admin/includes/function.php';
require ICONSULTSUPPORT_PLUGIN_DIR . '/admin/includes/admin_menu.php';
