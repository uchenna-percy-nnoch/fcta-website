<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

?>
<div class="wrap about-wrap">
    <?php iconsult__admin_menu_tabs('demos'); ?>
</div>